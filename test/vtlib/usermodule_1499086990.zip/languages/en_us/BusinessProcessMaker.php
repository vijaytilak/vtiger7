<?php

$languageStrings = array(
	'BusinessProcessMaker' => 'Business Process Maker',
    'Business Process Maker' => 'Business Process Maker',
);
