<?php

class BusinessProcessMaker_List_View extends Vtiger_Index_View {
	
	public function process(Vtiger_Request $request) {
		echo "<center><h1>Welcome to Business Process Maker<h1><h4>The support is enabled through Javascript</h4></center>";
	}
}